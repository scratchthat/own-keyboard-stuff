#!/bin/bash
git checkout amj60      # gets you on branch amj60
git fetch origin        # gets you up to date with origin
git merge origin/master
