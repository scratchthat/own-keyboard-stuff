#ifndef STM32_F072_ONEKEY_H
#define STM32_F072_ONEKEY_H
#include "chibios_test.h"
#endif

