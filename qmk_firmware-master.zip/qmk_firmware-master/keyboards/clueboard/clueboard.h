#ifndef CLUEBOARD_H
#define CLUEBOARD_H

#ifdef SUBPROJECT_rev1
    #include "rev1.h"
#endif
#ifdef SUBPROJECT_rev2
    #include "rev2.h"
#endif

#include "quantum.h"

#endif
