# skullY's Clueboard Layout

This layout is what I (@skullydazed) use on my personal Clueboards. I mostly use it for programming, CAD, and general typing.

The most notable change from the default layout is putting Ctrl on the Capslock key. I also swap Alt and Cmd because I mostly use a Mac day to day.
