# The default keymap for cluecard
