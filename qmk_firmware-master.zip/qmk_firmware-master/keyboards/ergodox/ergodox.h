#ifndef KEYBOARDS_ERGODOX_ERGODOX_H_
#define KEYBOARDS_ERGODOX_ERGODOX_H_
#ifdef SUBPROJECT_ez
    #include "ez.h"
#endif
#ifdef SUBPROJECT_infinity
    #include "infinity.h"
#endif

#endif /* KEYBOARDS_ERGODOX_ERGODOX_H_ */
