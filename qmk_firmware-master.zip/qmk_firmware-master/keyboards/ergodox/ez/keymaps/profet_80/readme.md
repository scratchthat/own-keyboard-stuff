# ErgoDox 80 Default Configuration

This is based on the default Ergodox EZ keymap.
The difference is that this keymap supports 80 key layouts.
If you own an 80 key Ergodox, use this as an example to get your desired keymap.

**NOTE:** This layout is not physically supported by the Ergodox EZ.


![Default80](ergodox80.png)
