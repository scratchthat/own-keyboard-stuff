# Basic implementation for k.o,y variant of the adnw layout

adnw is a layout optimised for usage with german and english language
k.o,y is a variant of this layout
http://www.adnw.de/index.php?n=Main.SeitlicheNachbaranschl%C3%A4ge

The os must use the de_DE layout
