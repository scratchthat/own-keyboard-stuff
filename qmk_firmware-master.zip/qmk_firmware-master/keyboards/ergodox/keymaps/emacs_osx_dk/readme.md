# ErgoDox EZ Emacs-OSX-DeadKeys Configuration

Since I'm an Emacs user, ctrl keys are very important and gets a placement where the usual caps_lock is. There
are an extra pair of ctrls, just in case there where problems with the holding one's, but not as comfortable.

Gui button takes a predominant place on the thumb cluster, as I'm using a mac os x and it relies heavily on it.

Finally there is also two Right Alts to easily access to accented letters of the spanish alphabet.

![Default](default_highres.png)
