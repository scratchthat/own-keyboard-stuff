#ifndef CONFIG_USER_H
#define CONFIG_USER_H

#include "../../config.h"

#define ONESHOT_TAP_TOGGLE 2
#define ONESHOT_TIMEOUT 300

#undef LEADER_TIMEOUT
#define LEADER_TIMEOUT 300

#endif
