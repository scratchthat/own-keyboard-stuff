# ErgoDox EZ Plums Configuration

## Changelog

* Apr 23, 2016 (v0.1.0): 
  * Shortcut for iTerm2 quake style dropdown (Ctrl+`)
  * Shortcut for screen/tmux (Ctrl+a)
  * Shortcut for shush (Hyper+m)
  * Combo modifier for LGUI + LALT

![Plums](plums.png)
