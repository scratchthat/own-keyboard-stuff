# sethbc's Ergodox EZ keymap

Largely based on the Ergodox Infinity default keymap
