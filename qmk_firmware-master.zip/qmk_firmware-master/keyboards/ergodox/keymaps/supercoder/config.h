#ifndef CONFIG_USER_H
#define CONFIG_USER_H 1

#include "../../config.h"

#undef LOCKING_SUPPORT_ENABLE
#undef LOCKING_RESYNC_ENABLE

#endif
