# ErgoDox EZ OS X Simplified Configuration

This keyboard configuration replaces the hyper and meh keys with the command key. It also removes all of the meta keys that require a "hold" because I found that I hesitate when I type, which can accidentally fire those combinations. On the upper left of the left hand, I mimicked the Mac placement of tab and escape, and on the upper right of the right hand, I placed an additional enter key for convenience when breezing through prompts.

This is my standard working configuration for now, but I can see myself tweaking it as I use it more. I highly recommend you do the same.