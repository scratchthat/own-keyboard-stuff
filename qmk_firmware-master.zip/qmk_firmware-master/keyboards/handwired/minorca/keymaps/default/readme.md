# The Default Minorca Layout

Copied from https://github.com/pancinteractive/qmk_firmware/blob/master/keyboard/minorca_mkV/keymaps/default/keymap.c

It looks incomplete.