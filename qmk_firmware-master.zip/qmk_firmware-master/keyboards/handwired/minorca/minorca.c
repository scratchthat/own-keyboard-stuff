#include "minorca.h"

void matrix_init_kb(void) {

	matrix_init_user();
}