#ifndef MINORCA_H
#define MINORCA_H

#include "quantum.h"

#endif
