# The default keymap for handwired/traveller
this is a kitchen sink build 
