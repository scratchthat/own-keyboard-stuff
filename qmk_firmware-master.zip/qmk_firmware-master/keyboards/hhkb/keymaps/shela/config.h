#ifndef CONFIG_SHELA_H
#define CONFIG_SHELA_H

#include "../../config.h"

#undef TAPPING_TERM
#define TAPPING_TERM 230

#define ONESHOT_TAP_TOGGLE 2
#define ONESHOT_TIMEOUT 2000

#endif
