# Shela's HHKB Layout

Layer 0: US Layout  
Layer 1: Pseudo US Layout  
Layer 2: Dvorak Layout  
Layer 3: Mouse  
Layer 4: Tenkey  
Layer 5: HHKB Fn Key  
Layer 6: SpaceFN  

## Pseudo US Layout

On japanese Windows, HHKB Professional 2 US layout model recognized wrongly as JIS layout without changing OS settings.  
But, you can use HHKB like a US layout keyboard as it is.
