JD45 keyboard firmware
======================

TODO: to be updated.
