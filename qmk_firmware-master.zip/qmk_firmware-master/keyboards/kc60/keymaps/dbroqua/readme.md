# Dbroqua Layout

* Online keyboard layout editor: http://www.keyboard-layout-editor.com/#/gists/24fa7821d4955ec3c76037c8e159a199
* Online keyboard layout editor (caps layer): http://www.keyboard-layout-editor.com/#/gists/4136d4d1555d6f0d9403c21aaf50fd37
* Online keyboard layout editor (fn2 layer): http://www.keyboard-layout-editor.com/#/gists/cf4955f73f339020dbb41c15364e7e4f

# Programming Instructions:
Enter into programming mode and run the following command.
```
$ sudo KEYMAP=dbroqua make dfu
```