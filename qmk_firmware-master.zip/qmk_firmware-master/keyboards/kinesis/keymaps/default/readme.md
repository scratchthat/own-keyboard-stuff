# The default keymap for kinesis-advantage
