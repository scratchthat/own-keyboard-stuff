# a programmer friendly keymap for the kinesis-advantage
# not really baked yet. 
