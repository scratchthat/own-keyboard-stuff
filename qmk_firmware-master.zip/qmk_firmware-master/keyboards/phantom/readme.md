Phantom keyboard firmware
======================

TODO: to be updated.
