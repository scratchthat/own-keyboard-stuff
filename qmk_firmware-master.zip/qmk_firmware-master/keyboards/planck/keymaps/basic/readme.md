# A more basic Planck Layout for copying

