#ifndef CONFIG_USER_H
#define CONFIG_USER_H
#endif

#include "../../config.h"

#define PREVENT_STUCK_MODIFIERS