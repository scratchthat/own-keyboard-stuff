check keymap.c to the layers

This Layout tries to emulate the Bone2 Variant of Neo2, and is intended to be used with a German QWERTZ Softwarelayout.
It has "üäöß" as it is optimized for a mix of German & English.
My favourite features are the placement of the special characters often used for programming right on the home row
and the number & navigation block combo, so you never have to move your hands from their home position.

Bone2 wiki page: http://wiki.neo-layout.org/wiki/Bone