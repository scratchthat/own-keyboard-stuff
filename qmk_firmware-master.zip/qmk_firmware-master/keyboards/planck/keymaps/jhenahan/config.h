#ifndef CONFIG_USER_H
#define CONFIG_USER_H

#include "../../config.h"

#define FORCE_NKRO
#define WORKMAN_SOUND COLEMAK_SOUND

#endif
